library(dfa)
source("util.R")

#generate simulated data
scenario = 1 #scenario 1 or senario 2
list2env(generate_data(scenario), globalenv())#generate data

#set random seed
seed = 0
set.seed(seed)

#MCMC configurations
N = 5000 #number of MCMC iterations
burnin = N / 2 #burn-in
thin = 5 #thinning


#########MCMC##############
time = proc.time()
re = DFA(as.matrix(y),
         as.matrix(z),
         N,
         burnin,
         thin,
         P_fix1,
         B_fix1,
         B_fix2,
         C_fix1,
         C_fix2)
time = proc.time() - time
list2env(re[[1]], globalenv())
list2env(re[[2]], globalenv())
list2env(re[[3]], globalenv())

##summaries: hamming distances
sum(abs(B_est - B_true[, -(1:(fix1K + fix2K))]))
sum(C_est != C_true[, -(1:(fix1K + fix2K))])
sum(abs(cbind(P_fix2_est, P_est) - P_true[, -(1:fix1K)]))

##graphics
#posterior of number of diseases
par(mar = c(2, 3, 3, 2) + 0.1)
barplot(table(K + 2) / length(K),
        cex.lab = 2,
        cex.axis = 2) #we add 2 fixed/known diseases

#heatmap of true patient-disease relationships
heatmap.2(
  P_true,
  col = c(0, 3),
  labRow = "",
  scale = "none",
  dendrogram = "none",
  Rowv = FALSE,
  Colv = FALSE,
  trace = "none",
  key = FALSE,
  lhei = c(.2, 4),
  lwid = c(.2, 1)
)

#heatmap of estimated patient-disease relationships
heatmap.2(
  cbind(P_fix1, P_fix2_est, P_est),
  col = c(0, 3),
  labRow = "",
  scale = "none",
  dendrogram = "none",
  Rowv = FALSE,
  Colv = FALSE,
  trace = "none",
  key = FALSE,
  lhei = c(.2, 4),
  lwid = c(.2, 1)
)

#heatmap of true binary symptom-disease relationships
heatmap.2(
  B_true,
  col = c(0, 3),
  labRow = "",
  scale = "none",
  dendrogram = "none",
  Rowv = FALSE,
  Colv = FALSE,
  trace = "none",
  key = FALSE,
  lhei = c(.2, 4),
  lwid = c(.2, 1)
)
#heatmap of estimated binary symptom-disease relationships
heatmap.2(
  cbind(B_fix1_est, B_fix2_est, B_est),
  col = c(0, 3),
  labRow = "",
  scale = "none",
  dendrogram = "none",
  Rowv = FALSE,
  Colv = FALSE,
  trace = "none",
  key = FALSE,
  lhei = c(.2, 4),
  lwid = c(.2, 1)
)

#heatmap of true ternary symptom-disease relationships
heatmap.2(
  C_true,
  col = c(5, 0, 3),
  labRow = "",
  scale = "none",
  dendrogram = "none",
  Rowv = FALSE,
  Colv = FALSE,
  trace = "none",
  key = FALSE,
  lhei = c(.2, 4),
  lwid = c(.2, 1)
)

#heatmap of estimated ternary symptom-disease relationships
heatmap.2(
  cbind(C_fix1_est, C_fix2_est, C_est),
  col = c(5, 0, 3),
  labRow = "",
  scale = "none",
  dendrogram = "none",
  Rowv = FALSE,
  Colv = FALSE,
  trace = "none",
  key = FALSE,
  lhei = c(.2, 4),
  lwid = c(.2, 1)
)