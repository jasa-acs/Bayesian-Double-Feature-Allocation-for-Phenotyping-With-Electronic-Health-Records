#generate a n by KK binary matrix from IBP with concentration parameter alpha
generate_P = function(n, alpha, KK, seed) {
  set.seed(seed)
  tempK = 100
  K = Inf
  flag = 1
  while ((K != KK) | (flag == 1)) {
    #set.seed(seed)
    #seed=seed+1
    Z = matrix(0, n, tempK)
    nfirst = rpois(1, alpha)
    
    if (nfirst == 0) {
      next
    }
    Z[1, 1:nfirst] = 1
    m = colSums(Z)
    max_c = nfirst
    for (i in 2:n) {
      rns = runif(tempK)
      pr = m / i
      v = pr > rns
      Z[i,] = v
      k_more = rpois(1, alpha / i)
      if (k_more >= 1) {
        Z[i, max_c:(max_c + k_more)] = 1
      }
      max_c = max_c + k_more
      m = colSums(Z)
    }
    K = max_c
    Z = Z[, 1:K]
    if (all(m[1:K] > .05 * n)) {
      flag = 0
    } else{
      flag = 1
    }
  }
  return (Z)
}


#generate simulated data

generate_data = function(s = 1,
                         seed = 1,
                         tt = 1) {
  set.seed(1987)
  ##########generate data##########
  n = 300#sample size
  K_true = 6#number of diseases
  p = 24#number of binary symptoms
  q = 24#number of trinary symptoms
  P_true = generate_P(n, 1, K_true, seed)
  P_true = P_true[, order(colSums(P_true), decreasing = TRUE)]
  
  B_true = matrix(0, p, K_true)
  C_true = matrix(0, q, K_true)
  B_true[1:4, 1] = 1
  B_true[5:8, 2] = 1
  B_true[9:12, 3] = 1
  B_true[13:16, 4] = 1
  B_true[17:20, 5] = 1
  B_true[21:24, 6] = 1
  B_true = (B_true + matrix(rbinom(p * K_true, 1, .1), nrow = p) > 0) +
    0
  C_true[1:4, 1] = 1
  C_true[5:8, 2] = -1
  C_true[9:12, 3] = 1
  C_true[13:16, 4] = -1
  C_true[17:20, 5] = 1
  C_true[21:24, 6] = -1
  C_tmp = matrix(apply(rmultinom(q * K_true, 1, c(.05, .8, .05)), 2, function (x)
    which(x == 1)), nrow = q) - 2
  C_tmp[C_true != 0] = 0
  C_true = C_true + C_tmp
  
  
  
  if (s == 1) { #generate from dfa model
    fix1K = 1#1 diseases with diagnoses
    fix2K = 1#1 diseases without diagnoses
    P_fix1 = matrix(0, n, fix1K)
    P_fix1[,] = P_true[, 1:fix1K]
    B_fix1 = matrix(0, p, fix1K)
    B_fix1[] = B_true[, 1:fix1K]
    B_nonfix1_ind = list(rep(0, 0))
    B_fix2 = matrix(0, p, fix2K)
    B_fix2[] = B_true[, (fix1K + 1):(fix1K + fix2K)]
    B_nonfix2_ind = list(rep(0, 0))
    C_fix1 = matrix(0, q, fix1K)
    C_fix2 = matrix(0, q, fix2K)
    C_nonfix1_ind = list(rep(0, 0))
    C_fix1[] = C_true[, 1:fix1K]
    C_nonfix2_ind = list(rep(0, 0))
    C_fix2[] = C_true[, (fix1K + 1):(fix1K + fix2K)]
    
    W = c(1.2, 2.4, 2.8, 3.2, 3.6, 4.1)
    ZETA = rep(log(1 / 19), p)
    ETAP = rep(log(1 / 38), q)
    ETAM = rep(log(1 / 38), q)
    z = matrix(0, n, p)
    y = matrix(0, n, q)
    for (i in 1:n) {
      for (j in 1:p) {
        z[i, j] = rbinom(1, 1, 1 / (1 + exp(-sum(
          P_true[i,] * W * B_true[j,]
        ) - ZETA[j])))
      }
      for (j in 1:q) {
        prob = c(exp(sum(P_true[i,] * W * (
          C_true[j,] == -1
        )) + ETAM[j]), 1, exp(sum(P_true[i,] * W * (C_true[j,] == 1)) + ETAP[j]))
        prob = prob / sum(prob)
        y[i, j] = which(rmultinom(1, 1, prob) == 1) - 2
      }
    }
    if (fix1K > 0) {
      for (k in 1:fix1K) {
        B_nonfix1_ind[[k]] = B_nonfix1_ind[[k]] - 1
        C_nonfix1_ind[[k]] = C_nonfix1_ind[[k]] - 1
      }
    }
    if (fix2K > 0) {
      for (k in 1:fix2K) {
        B_nonfix2_ind[[k]] = B_nonfix2_ind[[k]] - 1
        C_nonfix2_ind[[k]] = C_nonfix2_ind[[k]] - 1
      }
    }
  } else{ #generate fro latent factor models
    phi = P_true * matrix(4 * runif(n * K_true), n, K_true) #Latent factors
    Lam_B = B_true * matrix(4 * runif(p * K_true), p, K_true)#*matrix((-1)^rbinom(p*K_true,1,.5)*runif(p*K_true,2,6),p,K_true) #Binary loading matrix
    Lam_C = C_true * matrix(4 * runif(q * K_true), q, K_true)#*matrix(runif(q*K_true,2,6),q,K_true) #trinary loading matrix
    set.seed(seed)
    #generated continuous variables from latent factor model
    zc = phi %*% t(Lam_B) + 1 * matrix(rnorm(n * p), n, p)
    yc = phi %*% t(Lam_C) + 1 * matrix(rnorm(n * q), n, q)
    #threshold the continuous variables to get categorical variables
    z = (zc > tt) + 0
    y = (yc > tt) - (yc < -tt)
    B_fix1 = B_fix2 = B_nonfix1_ind = B_nonfix2_ind = C_fix1 = C_fix2 =
      C_nonfix1_ind = C_nonfix2_ind = P_fix1 = fix1K = fix2K = NULL
    
  }
  return (
    list(
      B_fix1 = B_fix1,
      B_fix2 = B_fix2,
      B_nonfix1_ind = B_nonfix1_ind,
      B_nonfix2_ind = B_nonfix2_ind,
      B_true = B_true,
      C_fix1 = C_fix1,
      C_fix2 = C_fix2,
      C_nonfix1_ind = C_nonfix1_ind,
      C_nonfix2_ind = C_nonfix2_ind,
      C_true = C_true,
      P_fix1 = P_fix1,
      P_true = P_true,
      y = y,
      z = z,
      fix1K = fix1K,
      fix2K = fix2K
    )
  )
}
